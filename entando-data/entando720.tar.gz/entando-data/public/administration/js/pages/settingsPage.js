$(function(){
    $('.bootstrap-switch').bootstrapSwitch();
});