In questa directory bisogna inserire i css del front end.
Suggeriamo, ma non è obbligatoria una alberatura delle directory per i css del tipo:

- pagemodels/
- contentmodels/
- showlets/

E' la directory a cui punta il tah <wp:cssURL />