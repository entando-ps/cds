Insert here all the images composing the frontend layout.
The <wp:imgURL /> tag points this folder.